/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package structs;

import java.io.Serializable;

/**
 *
 * @author 3070130-3070175
 */
public class AbstractMessage implements Serializable{
    private static final long serialVersionUID = 1L;
    
}
